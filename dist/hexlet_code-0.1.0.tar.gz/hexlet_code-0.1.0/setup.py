# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Artem-bav/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Artem-bav/python-project-49/actions)\n# my Maintainability Badge\n<a href="https://codeclimate.com/github/Artem-bav/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/98b0b72b9f22a6df4b22/maintainability" /></a>\n# my asciinema URL game\nhttps://asciinema.org/a/WxFrv9Vo241nB2lULlV5oZtM6\n# my asciinema calc \nhttps://asciinema.org/a/aa42Ad1igMSTfdZkA4F7z76z8\n# my asciinema gcd\nhttps://asciinema.org/a/QIXynmNNC8UVCS7KZNCwasKri\n# my asciinema progression\nhttps://asciinema.org/a/UKXUKBZbxSxKyiLG4scHgh9QD\n# my asciinema prime\nhttps://asciinema.org/a/SV3Ho4AZLWnUlw4Cytb327eK8\n',
    'author': 'Artem-bav',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
