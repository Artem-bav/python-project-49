### Hexlet tests and linter status:
[![Actions Status](https://github.com/Artem-bav/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Artem-bav/python-project-49/actions)
# my Maintainability Badge
<a href="https://codeclimate.com/github/Artem-bav/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/98b0b72b9f22a6df4b22/maintainability" /></a>
# my asciinema URL game
https://asciinema.org/a/WxFrv9Vo241nB2lULlV5oZtM6
# my asciinema calc 
https://asciinema.org/a/aa42Ad1igMSTfdZkA4F7z76z8
# my asciinema gcd
https://asciinema.org/a/QIXynmNNC8UVCS7KZNCwasKri
# my asciinema progression
https://asciinema.org/a/UKXUKBZbxSxKyiLG4scHgh9QD
