def main():
    from brain_games.games.progression_game import progression_user
    print('Welcome to the Brain Games!')
    progression_user()


if __name__ == '__main__':
    main()
