def logic_f():
    print('good ljgic!!!')
