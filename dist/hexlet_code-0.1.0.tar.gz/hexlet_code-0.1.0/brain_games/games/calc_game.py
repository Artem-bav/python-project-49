def calc_user():
    #from brain_games.games.logic_game import logic_f #вызов логики
    from brain_games import logic_game 
    logic_game.logic_f()
    print('artem kozel')
