def main():
    from brain_games.games.even_game import name_user
    print('Welcome to the Brain Games!')
    name_user()


if __name__ == '__main__':
    main()
