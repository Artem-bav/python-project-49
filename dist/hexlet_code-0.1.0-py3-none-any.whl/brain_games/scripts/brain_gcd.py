def main():
    from brain_games.games.gcd_game import gcd_user
    print('Welcome to the Brain Games!')
    gcd_user()


if __name__ == '__main__':
    main()
